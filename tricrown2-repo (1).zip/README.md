# TRI-CROWN 2.0 — PQ-Hybrid Encryption (Minimal Demo)

Standards-only, crypto-agile, with deterministic nonces and key-commitment.

## Quick start
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python examples/demo_tricrown_min.py
python examples/demo_tricrown_hybrid.py   # adds ML-KEM + McEliece if liboqs-python is installed
```

## Enable PQ
```bash
pip install liboqs-python
python examples/demo_tricrown_hybrid.py
```

## What this proves
- Handshake derives identical root keys across peers.
- AEAD decrypts, tamper is rejected by commit-before-open.
- Nonces are unique and deterministic.
- Rekey refresh works for both peers.

## Files
- `src/tricrown_min.py` — X25519 + HKDF(SHA3-512) + ChaCha20-Poly1305 + key-commitment.
- `src/tricrown_hybrid.py` — adds ML-KEM-1024 and Classic-McEliece-6960119 via liboqs when available.
- `examples/` — runnable demos.

## Security notes
This is a reference. Use audited PQ libs in production, constant-time everywhere, zeroize secrets.
