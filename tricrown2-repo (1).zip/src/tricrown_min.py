
import os, base64
from dataclasses import dataclass
from hashlib import sha3_256, sha3_512
from hmac import compare_digest
from typing import Tuple, Dict
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

SUITE_ID = b"TRICROWN2-PQ-min"

def hkdf_extract(salt:bytes, ikm:bytes)->bytes:
    return HKDF(algorithm=hashes.SHA3_512(), length=64, salt=salt, info=b"TRICROWN2 extract").derive(ikm)

def hkdf_expand(prk:bytes, info:bytes, L:int)->bytes:
    return HKDF(algorithm=hashes.SHA3_512(), length=L, salt=None, info=info).derive(prk)

def transcript_hash(parts:list[bytes])->bytes:
    h=sha3_512()
    for p in parts: h.update(p)
    return h.digest()

def commit_tag(kc:bytes, sid:bytes, seq:int, nonce:bytes, aad:bytes, ct:bytes)->bytes:
    h=sha3_256()
    for b in (kc, SUITE_ID, sid, seq.to_bytes(8,'big'), nonce, aad, ct): h.update(b)
    return h.digest()

def derive_nonce(k_nonce:bytes, seq:int, nlen:int=12)->bytes:
    return hkdf_expand(k_nonce, b"nonce"+seq.to_bytes(8,'big'), nlen)

def next_mk(ck:bytes, seq:int)->Tuple[bytes,bytes]:
    mk = hkdf_expand(ck, b"mk"+seq.to_bytes(8,'big'), 32)
    ck2 = hkdf_extract(b"step", ck)
    return mk, ck2

@dataclass
class Chains:
    rk: bytes
    ck_s: bytes
    ck_r: bytes
    k_commit: bytes
    k_nonce: bytes

@dataclass
class Ctx:
    role: str
    sid: bytes
    th: bytes
    chains: Chains
    x_sk: x25519.X25519PrivateKey
    x_pk: x25519.X25519PublicKey
    peer_x_pk: x25519.X25519PublicKey|None
    last_chlo: bytes|None = None
    last_shlo: bytes|None = None
    seq_s:int=0
    seq_r:int=0

def ctx_init(role:str)->Ctx:
    x_sk = x25519.X25519PrivateKey.generate()
    x_pk = x_sk.public_key()
    sid = os.urandom(16)
    chains = Chains(b"",b"",b"",b"",b"")
    return Ctx(role, sid, b"", chains, x_sk, x_pk, None, 0, 0)

def client_hello(ctx:Ctx)->bytes:
    pk = ctx.x_pk.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    msg=b"CHLO|"+SUITE_ID+b"|"+base64.b64encode(ctx.sid)+b"|"+base64.b64encode(pk)
    ctx.last_chlo = msg
    ctx.th = transcript_hash([msg])
    return msg

def server_hello(ctx_srv:Ctx, chlo:bytes)->bytes:
    parts = chlo.split(b"|")
    sid = parts[2]
    pkb = parts[3]
    ctx_srv.sid = base64.b64decode(sid)
    Xe_c = x25519.X25519PublicKey.from_public_bytes(base64.b64decode(pkb))
    ctx_srv.peer_x_pk = Xe_c
    pk = ctx_srv.x_pk.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    msg=b"SHLO|"+SUITE_ID+b"|"+base64.b64encode(pk)
    ctx_srv.last_shlo = msg
    ctx_srv.last_chlo = chlo
    ctx_srv.th = transcript_hash([chlo, msg])
    return msg

def client_finish(ctx:Ctx, shlo:bytes)->bytes:
    Xe_s = x25519.X25519PublicKey.from_public_bytes(base64.b64decode(shlo.split(b"|")[2]))
    ss_X = ctx.x_sk.exchange(Xe_s)
    th_pair = transcript_hash([ctx.last_chlo, shlo])
    mix = hkdf_extract(th_pair, ss_X)
    hs = hkdf_expand(mix, b"TRICROWN2 hs"+SUITE_ID, 128)
    ctx.chains = Chains(hs[0:32], hs[32:64], hs[64:96], hs[96:128-32], hs[128-32:128])
    msg=b"FIN|ok"
    ctx.last_shlo = shlo
    ctx.th = transcript_hash([th_pair, msg])
    return msg

def server_finish(ctx_srv:Ctx, fin:bytes)->None:
    ss_X = ctx_srv.x_sk.exchange(ctx_srv.peer_x_pk)
    th_pair = transcript_hash([ctx_srv.last_chlo, ctx_srv.last_shlo])
    mix = hkdf_extract(th_pair, ss_X)
    hs = hkdf_expand(mix, b"TRICROWN2 hs"+SUITE_ID, 128)
    ctx_srv.chains = Chains(hs[0:32], hs[64:96], hs[32:64], hs[96:128-32], hs[128-32:128])
    ctx_srv.th = transcript_hash([th_pair, fin])

def seal(ctx:Ctx, aad:bytes, pt:bytes)->Dict:
    seq = ctx.seq_s; ctx.seq_s += 1
    mk, ctx.chains.ck_s = next_mk(ctx.chains.ck_s, seq)
    nonce = derive_nonce(ctx.chains.k_nonce, seq, 12)
    aead = ChaCha20Poly1305(mk)
    ct = aead.encrypt(nonce, pt, aad)
    commit = commit_tag(ctx.chains.k_commit, ctx.sid, seq, nonce, aad, ct)
    return {"seq":seq, "nonce":nonce, "aad":aad, "ct":ct, "commit":commit}

def open_(ctx:Ctx, rec:Dict)->bytes:
    seq = rec["seq"]
    expect = commit_tag(ctx.chains.k_commit, ctx.sid, seq, rec["nonce"], rec["aad"], rec["ct"])
    if not compare_digest(expect, rec["commit"]):
        raise ValueError("commitment mismatch")
    mk, ctx.chains.ck_r = next_mk(ctx.chains.ck_r, seq)
    aead = ChaCha20Poly1305(mk)
    return aead.decrypt(rec["nonce"], rec["ct"], rec["aad"])

def rekey(ctx:Ctx)->None:
    mix = hkdf_extract(ctx.th, ctx.chains.rk)
    hs = hkdf_expand(mix, b"TRICROWN2 rk"+SUITE_ID, 128)
    if ctx.role == 'server':
        ctx.chains = Chains(hs[0:32], hs[64:96], hs[32:64], hs[96:128-32], hs[128-32:128])
    else:
        ctx.chains = Chains(hs[0:32], hs[32:64], hs[64:96], hs[96:128-32], hs[128-32:128])
