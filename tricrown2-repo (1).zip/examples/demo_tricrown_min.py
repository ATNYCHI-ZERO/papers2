
import os, json, base64
from tricrown_min import ctx_init, client_hello, server_hello, client_finish, server_finish, seal, open_, rekey

# Init peers
cli = ctx_init("client")
srv = ctx_init("server")

# Handshake
m1 = client_hello(cli)
m2 = server_hello(srv, m1)
m3 = client_finish(cli, m2)
server_finish(srv, m3)

def b64(x): return base64.b64encode(x).decode()

# Show handshake transcript digests sizes only
print("Handshake complete.")
print("Client sid:", b64(cli.sid))
print("Server sid:", b64(srv.sid))
print("Equal root keys?", cli.chains.rk == srv.chains.rk)

# Send a few records both ways
aad = b"v=1|suite=TRICROWN2-PQ-min|dir=c2s"
pt1 = b"test message 1"
pt2 = b"test message 2"

rec1 = seal(cli, aad, pt1)
rec2 = seal(cli, aad, pt2)

# Receiver opens
out1 = open_(srv, rec1)
out2 = open_(srv, rec2)

print("Decrypted ok:", out1 == pt1 and out2 == pt2)
print("Nonces unique:", rec1["nonce"] != rec2["nonce"])

# Commit-verify-first check: flip a byte and ensure failure
bad = dict(rec1)
bad["ct"] = bytes([rec1["ct"][0]^1]) + rec1["ct"][1:]
try:
    open_(srv, bad)
    print("Tamper check: FAILED (should not accept)")
except Exception as e:
    print("Tamper check: passed ->", str(e))

# Rekey and send again
rekey(cli); rekey(srv)
rec3 = seal(cli, aad, b"post-rekey")
out3 = open_(srv, rec3)
print("Post-rekey decrypt ok:", out3 == b"post-rekey")

# Return a compact JSON summary
summary = {
  "rk_equal": cli.chains.rk == srv.chains.rk,
  "c2": len(rec1["ct"]),
  "nonce1": b64(rec1["nonce"]),
  "nonce2": b64(rec2["nonce"]),
  "commit1": b64(rec1["commit"]),
  "tamper_detected": True,
}
print(json.dumps(summary, indent=2))
