import runpy, os
def test_min_demo_runs():
    out = runpy.run_path('examples/demo_tricrown_min.py')
    # no exception == pass
